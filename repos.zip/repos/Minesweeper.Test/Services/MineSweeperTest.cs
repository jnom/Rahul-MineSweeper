﻿using FakeItEasy;
using FakeItEasy.Configuration;
using MineSweeper.Application.Interfaces;
using MineSweeper.Application.Services;
using Xunit.Abstractions;
using service = MineSweeper.Application.Services;

namespace Minesweeper.Test.Services
{

    public class MineSweeperTest
    {
        [Fact]
        public void Grid_Positive_Initialize_SuccessfullyCompleteTheGame()
        {
            // Arrange
            var mines = A.Fake<IMineSweeper>();

            var mineSweeper = new service.MineSweeper(4, 0);
            Console.SetIn(new StringReader("D4"));

            A.CallTo(() => mines.ReadKey(false)).WithAnyArguments();
            
            // Act
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);
                mineSweeper.Start(false);
                string expected = "Congratulations, you have won the game!";
                // Assert
                Assert.Contains(expected, sw.ToString());
            }
        }

        [Fact]
        public void Grid_Negative_Initialize_RevealedMines()
        {
            // Arrange
            var mines = A.Fake<IMineSweeper>();

            var mineSweeper = new service.MineSweeper(4, 16);
            Console.SetIn(new StringReader("D4"));

            A.CallTo(() => mines.ReadKey(false)).WithAnyArguments();

            // Act
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);
                mineSweeper.Start(false);
                string expected = "Oh no, you detonated a mine! Game over.";
                // Assert
                Assert.Contains(expected, sw.ToString());
            }
        }

    }
}