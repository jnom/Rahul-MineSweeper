﻿using MineSweeper.Application.Services;

namespace Minesweeper.Test.Services
{
    public class GridTest
    {
        [Fact]
        public void Grid_Positive_Initialize_PlaceMines()
        {
            // Arrange
            int gridSize = 4;
            var grid = new Grid(gridSize);
            bool[,] DisplayedCells = new bool[4, 4];
            int NoOfMines = 2;

            // Act
            grid.Display(DisplayedCells);
            grid.PlaceMines(NoOfMines);
            var result = grid.GetField();

            int totalMines = 0;
            bool mines = false;
            foreach (char c in result)
            {
                if (c == 'X')
                {
                    totalMines++;
                    mines = true;
                }
            }

            // Assert
            Assert.Equal(16, result.Length);
            Assert.Equal(NoOfMines, totalMines);
            Assert.True(mines);
        }

        [Fact]
        public void Grid_Negative_Initialize_PlaceMines()
        {
            // Arrange
            int gridSize = 4;
            var grid = new Grid(gridSize);
            bool[,] DisplayedCells = new bool[4, 4];
            int NoOfMines = 0;

            // Act
            grid.Display(DisplayedCells);
            grid.PlaceMines(NoOfMines);
            var result = grid.GetField();

            bool mines = false;
            foreach (char c in result)
            {
                if (c == 'X')
                    mines = true;
            }

            // Assert
            Assert.False(mines);
        }
    }
}
