﻿using MineSweeper.Application.Services;

namespace Minesweeper.Test.Services
{
    public class SupportingServicesTest
    {
        [Fact]
        public void GetGridSize_Positive_UserInput_ValidSize()
        {
            // Arrange
            var supportingServices = new SupportingServices();
            int gridSize = 5;
            Console.SetIn(new StringReader(gridSize.ToString()));

            // Act
            var result = supportingServices.GetGridSize();

            // Assert
            Assert.Equal(gridSize, result);
        }

        [Fact]
        public void GetNumberOfMines_Positive_UserInput_ValidSize()
        {
            // Arrange
            var supportingServices = new SupportingServices();
            int noOfMine = 5;
            Console.SetIn(new StringReader(noOfMine.ToString()));

            // Act
            var result = supportingServices.GetNumberOfMines(noOfMine);

            // Assert
            Assert.Equal(noOfMine, result);
        }
    }
}
