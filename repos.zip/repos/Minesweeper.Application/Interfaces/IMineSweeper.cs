﻿namespace MineSweeper.Application.Interfaces
{
    public interface IMineSweeper
    {
        /// <summary>
        /// Start
        /// </summary>
        void Start(bool Replay = true);

        /// <summary>
        /// ReadKey
        /// </summary>
        /// <param name="isValid"></param>
        void ReadKey(bool isValid = true);
    }
}
