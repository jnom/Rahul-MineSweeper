﻿namespace MineSweeper.Application.Interfaces
{
    /// <summary>
    /// Grid calculation
    /// </summary>
    public interface IGrid
    {
        /// <summary>
        /// Display
        /// </summary>
        /// <param name="DisplayedCells"></param>
        public void Display(bool[,] DisplayedCells);

        /// <summary>
        /// PlaceMines
        /// </summary>
        /// <param name="numMines"></param>
        public void PlaceMines(int numMines);

        /// <summary>
        /// GetField
        /// </summary>
        /// <returns></returns>
        public char[,] GetField();
    }
}
