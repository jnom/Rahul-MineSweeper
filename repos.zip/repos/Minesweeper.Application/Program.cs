﻿using MineSweeper.Application.Interfaces;
using MineSweeper.Application.Services;
using Service = MineSweeper.Application.Services;
class Program
{
    /// <summary>
    /// Main
    /// </summary>
    /// <param name="args"></param>
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Welcome to Minesweeper!\n");
            
            SupportingServices supportingServices = new SupportingServices();

            //get Grid size from user
            int gridSize = supportingServices.GetGridSize();
            //Calculate max mines
            int maxMines = (int)(gridSize * gridSize * 0.35);
            //get and validate #mines from user
            int numMines = supportingServices.GetNumberOfMines(maxMines);

            IMineSweeper game = new Service.MineSweeper(gridSize, numMines);
            game.Start();
        }
    }
}