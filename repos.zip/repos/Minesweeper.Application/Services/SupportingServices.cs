﻿namespace MineSweeper.Application.Services
{
    public class SupportingServices
    {
        /// <summary>
        /// Get and validate Grid Size
        /// </summary>
        /// <returns></returns>
        public int GetGridSize()
        {
            int minSize = 2;
            int maxSize = 10;
            int gridSize;
            string input;
            do
            {
                Console.WriteLine("Enter the size of the grid (e.g. 4 for a 4x4 grid): ");
                if (int.TryParse(input = Console.ReadLine(), out gridSize))
                {
                    if (gridSize < minSize)
                    {
                        Console.WriteLine($"Minimum size of grid is {minSize}.");
                    }
                    else if (gridSize > maxSize)
                    {
                        Console.WriteLine($"Maximum size of grid is {maxSize}.");
                    }
                }
                else
                {
                    Console.WriteLine("Incorrect input.");
                }
            } while (!int.TryParse(input, out gridSize) || gridSize < minSize || gridSize > maxSize);

            return gridSize;
        }

        /// <summary>
        /// Get and validate Number Of Mines
        /// </summary>
        /// <param name="maxMines"></param>
        /// <returns></returns>
        public int GetNumberOfMines(int maxMines)
        {
            int minMines = 1;
            int numMines;
            string input;
            do
            {
                Console.WriteLine($"Enter the number of mines (maximum is 35% of the total squares ({maxMines})): ");

                if (int.TryParse(input = Console.ReadLine(), out numMines))
                {
                    if (numMines < minMines)
                    {
                        Console.WriteLine($"There must be at least 1 mine.");
                    }
                    else if (numMines > maxMines)
                    {
                        Console.WriteLine($"Maximum number is 35% of total squares. ({maxMines})");
                    }
                }
                else
                {
                    Console.WriteLine("Incorrect input.");
                }
            } while (!int.TryParse(input, out numMines) || numMines < minMines || numMines > maxMines);

            return numMines;
        }
    }
}
