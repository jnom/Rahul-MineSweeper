﻿using MineSweeper.Application.Interfaces;

namespace MineSweeper.Application.Services
{
    /// <summary>
    /// Grid desininging
    /// </summary>
    public class Grid : IGrid
    {
        /// <summary>
        /// field
        /// </summary>
        private char[,] field;

        /// <summary>
        /// Constructor - Grid
        /// </summary>
        /// <param name="gridSize"></param>
        public Grid(int gridSize)
        {
            field = new char[gridSize, gridSize];
            Initialize();
        }

        /// <summary>
        /// Initialize grid
        /// </summary>
        private void Initialize()
        {
            int gridSize = field.GetLength(0);
            for (int i = 0; i < gridSize; i++)
            {
                for (int j = 0; j < gridSize; j++)
                {
                    field[i, j] = '_';
                }
            }
        }

        /// <summary>
        /// Display grid
        /// </summary>
        /// <param name="DisplayedCells"></param>
        public void Display(bool[,] DisplayedCells)
        {
            int gridSize = field.GetLength(0);

            Console.WriteLine("\nHere is your minefield:");
            Console.Write("  ");
            for (int col = 0; col < gridSize; col++)
            {
                Console.Write($"{col + 1} ");
            }
            Console.WriteLine();

            for (int row = 0; row < gridSize; row++)
            {
                Console.Write((char)('A' + row) + " ");
                for (int col = 0; col < gridSize; col++)
                {
                    char cell = DisplayedCells[row, col] ? field[row, col] : '_';
                    Console.Write(cell + " ");
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// PlaceMines
        /// </summary>
        /// <param name="numMines"></param>
        public void PlaceMines(int numMines)
        {
            Random random = new Random();
            int gridSize = field.GetLength(0);

            for (int i = 0; i < numMines; i++)
            {
                int row, col;
                do
                {
                    row = random.Next(gridSize);
                    col = random.Next(gridSize);
                } while (field[row, col] == 'X');

                field[row, col] = 'X';
            }

            //Code for local testing 
            //field[0, 1] = 'X';
            //field[1, 1] = 'X';
            //field[2, 0] = 'X';
        }

        /// <summary>
        /// GetField
        /// </summary>
        /// <returns></returns>
        public char[,] GetField()
        {
            return field;
        }

    }
}
