﻿using MineSweeper.Application.Interfaces;

namespace MineSweeper.Application.Services
{
    /// <summary>
    /// MineSweeper
    /// </summary>
    public class MineSweeper : IMineSweeper
    {
        public IGrid minefield;
        private bool[,] DisplayedCells;
        private int gridSize;
        private int numMines;

        /// <summary>
        /// Constructor - MineSweeper
        /// </summary>
        /// <param name="gridSize"></param>
        /// <param name="numMines"></param>
        public MineSweeper(int gridSize, int numMines)
        {
            this.gridSize = gridSize;
            this.numMines = numMines;
            minefield = new Grid(gridSize);
            DisplayedCells = new bool[gridSize, gridSize];
        }

        /// <summary>
        /// Start
        /// </summary>
        public void Start(bool Replay = true)
        {
            minefield.PlaceMines(numMines);
            bool gameWon = false;

            while (!gameWon)
            {
                minefield.Display(DisplayedCells);

                string selectedCell = GetSelectedCell();
                int row = selectedCell[0] - 'A';
                int col = int.Parse(selectedCell.Substring(1)) - 1;

                if (minefield.GetField()[row, col] == 'X')
                {
                    Console.WriteLine("Oh no, you detonated a mine! Game over.");
                    break;
                }
                else
                {
                    int adjacentMines = CountAdjacentMines(row, col);
                    if (adjacentMines == 0)
                    {
                        bool[,] selectedCelles = new bool[gridSize, gridSize];
                        FloodFill(row, col, selectedCelles);
                        UpdateDisplayfiled();
                    }
                    else
                    {
                        DisplayedCells[row, col] = true;
                        minefield.GetField()[row, col] = char.Parse(adjacentMines.ToString());
                    }

                    Console.WriteLine($"This square contains {adjacentMines} adjacent mines.");

                    if (CheckGameWon())
                    {
                        minefield.Display(DisplayedCells);
                        Console.WriteLine("Congratulations, you have won the game!");
                        gameWon = true;
                        break;
                    }
                }
            }

            Console.WriteLine("Press any key to play again...");
            ReadKey(Replay);
           Console.WriteLine(Environment.NewLine);
        }

        public void ReadKey(bool Replay = true)
        {
            if (Replay)
                Console.ReadKey();
        }

        /// <summary>
        /// GetSelectedCell
        /// </summary>
        /// <returns></returns>
        private string GetSelectedCell()
        {
            string input;
            bool isValid;
            do
            {
                Console.Write("Select a square to reveal (e.g. A1): ");
                input = Console.ReadLine().ToUpper();

                isValid = !(input.Length < 2 || input.Length > 3 ||
                    input[0] < 'A' || input[0] >= 'A' + gridSize ||
                    input[1] < '1' || input[1] > '0' + gridSize ||
                    (input.Length == 3 && input[2] != '0'));

                if (!isValid)
                {
                    Console.WriteLine("Incorrect input.");
                }

            } while (!isValid);

            return input;
        }

        /// <summary>
        /// CountAdjacentMines
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        private int CountAdjacentMines(int row, int col)
        {
            int count = 0;

            for (int r = Math.Max(row - 1, 0); r <= Math.Min(row + 1, gridSize - 1); r++)
            {
                for (int c = Math.Max(col - 1, 0); c <= Math.Min(col + 1, gridSize - 1); c++)
                {
                    if (r == row && c == col) continue;
                    if (minefield.GetField()[r, c] == 'X') count++;
                }
            }

            return count;
        }

        /// <summary>
        /// FloodFill
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        private void FloodFill(int row, int col, bool[,] selectedCelles)
        {
            selectedCelles[row, col] = true;
            FillColumns(col, row);
            for (int r = Math.Max(row - 1, 0); r <= Math.Min(row + 1, gridSize - 1); r++)
            {
                for (int c = Math.Max(col - 1, 0); c <= Math.Min(col + 1, gridSize - 1); c++)
                {
                    if (DisplayedCells[r, c] = true && selectedCelles[r, c] == false && minefield.GetField()[r, c] == '0')
                    {
                        FloodFill(r, c, selectedCelles);
                    }
                }
            }
        }

        /// <summary>
        /// fillColumns
        /// </summary>
        /// <param name="col"></param>
        /// <param name="row"></param>
        private void FillColumns(int col, int row)
        {
            for (int r = Math.Max(row - 1, 0); r <= Math.Min(row + 1, gridSize - 1); r++)
            {
                for (int c = Math.Max(col - 1, 0); c <= Math.Min(col + 1, gridSize - 1); c++)
                {
                    if (minefield.GetField()[r, c] != 'X')
                    {
                        DisplayedCells[r, c] = true;
                        minefield.GetField()[r, c] = char.Parse(CountAdjacentMines(r, c).ToString());
                    }
                }
            }
        }

        /// <summary>
        /// CheckGameWon
        /// </summary>
        /// <returns></returns>
        private bool CheckGameWon()
        {
            int nonMineCount = gridSize * gridSize - numMines;

            int revealedCount = 0;
            for (int row = 0; row < gridSize; row++)
            {
                for (int col = 0; col < gridSize; col++)
                {
                    if (DisplayedCells[row, col]) revealedCount++;
                }
            }
            return revealedCount == nonMineCount;
        }

        /// <summary>
        /// UpdateDisplayfiled
        /// </summary>
        private void UpdateDisplayfiled()
        {
            for (int r = 0; r <= gridSize-1; r++)
            {
                for (int c = 0; c <= gridSize-1; c++)
                {
                    if (minefield.GetField()[r, c] != 'X' && minefield.GetField()[r, c] != '_')
                    {
                        DisplayedCells[r, c] = true;
                    }
                }
            }
        }
    }
}